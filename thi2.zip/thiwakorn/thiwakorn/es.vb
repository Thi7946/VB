﻿Public Class es

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        detailsbook.Show()
        Me.Hide()
    End Sub
End Class