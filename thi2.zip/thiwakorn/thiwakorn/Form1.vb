﻿Public Class Form1
    Enum Subject
        accel_world
        Index_Librorum_Prohibitorum
        death_march_to_the_parallel_world_rhapsody
        sword_art_online
        The_Eminence_in_Shadow
    End Enum
    Structure Detial
        Dim Subj As Subject
        Dim Names As String
        Dim Genre As String
        Dim Tags As String
        Dim Price As String
        Dim Pic As Object
    End Structure
    Dim Books(5) As Detial
    Dim CurrentBook As Integer = 0

    Sub ShowCurrentBook()
        txtName.Text = Books(CurrentBook).Subj.ToString
        txtPerson.Text = Books(CurrentBook).Names.ToString
        txtPrint.Text = Books(CurrentBook).Genre
        txtTag.Text = Books(CurrentBook).Tags
        txtPrice.Text = Books(CurrentBook).Price
        PictureBox1.Image = Books(CurrentBook).Pic
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        End
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        detailsbook.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Books(0).Subj = Subject.accel_world
        Books(0).Names = "สำนักพิมพ์เซนชู"
        Books(0).Genre = "หนักสือแปล ไลต์โนเวล"
        Books(0).Tags = "ผจญภัย แฟนตาซี"
        Books(0).Price = "160.00 บาท"
        Books(0).Pic = My.Resources.accelworld
        Books(1).Subj = Subject.Index_Librorum_Prohibitorum
        Books(1).Names = "ANIMAG (สำนักพิมพ์อนิแม็ก)"
        Books(1).Genre = "หนักสือแปล ไลท์โนเวล"
        Books(1).Tags = "ฮาเร็ม ตลก เวทมนตร์คาถา อนาคต"
        Books(1).Price = "150.00 บาท"
        Books(1).Pic = My.Resources.index
        Books(2).Subj = Subject.death_march_to_the_parallel_world_rhapsody
        Books(2).Names = "First Page Pro."
        Books(2).Genre = "ไลท์โนเวล หนังสือแปล"
        Books(2).Tags = "ผจญภัย แฟนตาซี ต่างโลก"
        Books(2).Price = "270.00 บาท"
        Books(2).Pic = My.Resources.DYT
        Books(3).Subj = Subject.sword_art_online
        Books(3).Names = "สำนักพิมพ์เซนชู."
        Books(3).Genre = "ไลท์โนเวล หนังสือแปล"
        Books(3).Tags = " แฟนตาซี เกมออนไลน์ "
        Books(3).Price = "200.00 บาท"
        Books(3).Pic = My.Resources.swordartonline
        Books(4).Subj = Subject.The_Eminence_in_Shadow
        Books(4).Names = "PHOENIX"
        Books(4).Genre = "ไลท์โนเวล หนังสือแปล"
        Books(4).Tags = "ตลก แฟนตาซี ต่างโลก top of the year 2020 : ไลท์โนเวล"
        Books(4).Price = "325.00 บาท"
        Books(4).Pic = My.Resources.TheEminenceinShadow
        ShowCurrentBook()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If CurrentBook > 0 Then
            CurrentBook -= 1
            ShowCurrentBook()
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If CurrentBook < 4 Then
            CurrentBook += 1
            ShowCurrentBook()
        End If
    End Sub
End Class
