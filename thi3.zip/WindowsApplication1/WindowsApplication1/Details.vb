﻿Public Class Details
    Dim a, b, c, d, ee As Object
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        End
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ทายผล.Show()
        Me.Hide()
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        Select Case ListBox1.SelectedIndex
            Case 0
                a = "FootBall"
                PictureBox1.Image = My.Resources.P1
                Label3.Text = a
                TextBox1.Text = "เป็นกีฬาประเภททีมที่เล่นระหว่างสองทีม โดยแต่ละทีมมีผู้เล่น 11 คน"
            Case 1
                b = "BasketBall"
                PictureBox1.Image = My.Resources.P2
                Label3.Text = b
                TextBox1.Text = "เป็นกีฬาชนิดหนึ่งแบ่งผู้เล่นเป็น 2 ทีม แต่ละทีมประกอบด้วยผู้เล่น 5 คน"
            Case 2
                c = "Golf"
                PictureBox1.Image = My.Resources.P3
                Label3.Text = c
                TextBox1.Text = "เป็นกีฬาหรือเกมประเภทบอลชนิดหนึ่ง ซึ่งผู้เล่นใช้ไม้หลายชนิดตีลูกบอลให้ลงหลุม"
            Case 3
                d = "Tennis"
                PictureBox1.Image = My.Resources.A4
                Label3.Text = d
                TextBox1.Text = "เป็นกีฬาที่เล่นในร่มหรือกางแจ้งก็ได้"
            Case 4
                ee = "VollyBall"
                PictureBox1.Image = My.Resources.VollyBallP5
                Label3.Text = ee
                TextBox1.Text = "เป็นกีฬาที่แข่งขันกันระหว่าง 2 ทีม ทีมละ 6 คน"
        End Select
    End Sub

    Private Sub Details_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ListBox1.Items.Add("FootBall")
        ListBox1.Items.Add("BasketBall")
        ListBox1.Items.Add("Golf")
        ListBox1.Items.Add("Tennis")
        ListBox1.Items.Add("VollyBall")
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub
End Class