﻿Public Class ทายผล
    Dim sport As String() = New String() {"FootBall", "BasketBall", "Golf", "Tennis", "VollyBall"}
    Dim blnUsed As Boolean() = New Boolean(sport.GetUpperBound(0)) {}
    Dim Count As Integer = 1
    Dim sp As String
    Dim score As Integer

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        End
    End Sub

    Private Sub ทายผล_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Hide()
        TextBox2.Hide()
        TextBox3.Hide()
        BtnNext.Hide()
        Array.Sort(sport)
        ComboBox1.DataSource = sport
        Displaysport()
    End Sub
    Function BuildPathName() As String
        Dim Output As String = sp
        Output &= ".jpg"
        Return Output
    End Function
    Function GetrandomNum() As Integer
        Dim ObjRandom As Random = New Random
        Dim intRandom As Integer
        Do
            intRandom = ObjRandom.Next(0, blnUsed.Length)
        Loop Until blnUsed(intRandom) = False
        blnUsed(intRandom) = True
        Return intRandom
    End Function
    Sub Displaysport()
        Dim intRandom As Integer = GetrandomNum()
        sp = sport(intRandom)
        Dim Path As String = BuildPathName()
        PictureBox1.Image = My.Resources.ResourceManager.GetObject(sp)
        Me.Text = "ผลทาย : ครั้งที่" & Count
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        TextBox1.Show()
        TextBox2.Show()
        TextBox3.Show()
        TextBox1.Text = "1.คลิกคำตอบจาก ComboBox แล้วคลิกทายผล"
        TextBox2.Text = "2.คลิกรูปถัดไปจากนี่น ทำเช่นเดี่ยวกับ ข้อ 1."
        TextBox3.Text = "3.เมื่อครบทุกรูปภาพแล้ว ให้คลิก ปิดโปรแกรม"
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Details.Show()
        Me.Hide()
    End Sub



    Private Sub BtnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnNext.Click
        Label3.Text = ""
        ComboBox1.SelectedIndex = 0
        Count += 1
        Button2.Enabled = True
        BtnNext.Enabled = False
        Displaysport()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim strResponse As String = Convert.ToString(ComboBox1.SelectedValue)
        If strResponse = sp Then
            Label3.Text = "ถูกต้อง"
            score += 1
            Label4.Text = score
        Else
            Label3.Text = " ผิดแล้ว"
        End If
        BtnNext.Show()
        If Count >= 5 Then
            Label3.Text &= ControlChars.CrLf & " Game Over"
            BtnNext.Enabled = False
            Button2.Enabled = False
            ComboBox1.Enabled = False
        Else
            Button2.Enabled = False
            BtnNext.Enabled = True

        End If
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub
End Class