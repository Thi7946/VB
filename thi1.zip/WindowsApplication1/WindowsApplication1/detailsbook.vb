﻿Public Class detailsbook

End Class