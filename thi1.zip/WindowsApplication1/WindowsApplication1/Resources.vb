﻿
Namespace My
    Class Resources

        Shared Function accelworld() As Object
            Throw New NotImplementedException
        End Function

        Shared Function index() As Object
            Throw New NotImplementedException
        End Function

        Shared Function deathmarchtotheparallelworldrhapsody() As Object
            Throw New NotImplementedException
        End Function

        Shared Function swordartonline() As Object
            Throw New NotImplementedException
        End Function

        Shared Function TheEminenceinShadow() As Object
            Throw New NotImplementedException
        End Function

    End Class
End Namespace
