﻿Public Class Main

    Private Sub DialogToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DialogToolStripMenuItem.Click
        Dialog.Show()
        Dialog.MdiParent = Me
        StaticAnimation.Hide()
        video.Hide()
    End Sub

    Private Sub StaticToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StaticToolStripMenuItem.Click
        StaticAnimation.Show()
        StaticAnimation.MdiParent = Me
        Dialog.Hide()
        video.Hide()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        End
    End Sub

    
    Private Sub VideoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VideoToolStripMenuItem.Click
        video.Show()
        video.MdiParent = Me
        StaticAnimation.Hide()
        Dialog.Hide()
    End Sub
End Class
