﻿Public Class StaticAnimation

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Const a_X As Integer = 50
        Const a_Y As Integer = 50
        Static HX As Integer = 1
        Static HY As Integer = 1
        Dim Location As Point

        Location = New Point(PictureBox1.Location.X + (HX * a_X), PictureBox1.Location.Y + (HY * a_Y))
        PictureBox1.Location = Location

        If (PictureBox1.Location.X <= 0) Or (PictureBox1.Location.X >= Me.ClientSize.Width - PictureBox1.Size.Width) Then
            HX = -HX
        End If

        If (PictureBox1.Location.Y <= 0) Or (PictureBox1.Location.Y >= Me.ClientSize.Height - PictureBox1.Size.Height) Then
            HY = -HY
        End If
    End Sub
End Class