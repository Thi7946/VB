﻿Public Class video

    Private Sub VideoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VideoToolStripMenuItem.Click
        AxWindowsMediaPlayer1.URL = "Dal.mp4"
    End Sub
End Class